Tunnetyökortit – hengitysharjoitus v5

GitHubiin:
1. Korvaa index.html tällä versiolla.
2. Korvaa sw.js tällä versiolla.
3. Lisää assets/vohveli-hengitys-v5.png.
4. Odota Actions-näkymässä vihreää merkkiä.
5. Avaa sivu ja tee Ctrl+F5.

Harjoitus:
- 5 kierrosta
- 4 sekuntia sisään
- 6 sekuntia ulos
- Pysäytä / Jatka
- Aloita alusta
